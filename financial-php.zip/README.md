# PHPSimpleCRUD-FS
Simple PHP CRUD application with data saved in JSON file

## Features

 - Read users JSON file and display data in bootstrap table
 - Implement create and update forms for a user
 - Implement delete user functionality
 - Add image uploading functionality to every user
 - Implement form validation and do not submit form on invalid data

The project was created while recording [youtube video](https://youtu.be/DWHZSkn5paQ)

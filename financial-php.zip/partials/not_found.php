<div class="alert alert-danger">
    <h3>User does not exist</h3>
</div>

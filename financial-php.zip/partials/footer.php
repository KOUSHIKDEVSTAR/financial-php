


<script>
    $(document).ready(function () {
    $('#example').DataTable();
    
});

</script>
</body>
</html>

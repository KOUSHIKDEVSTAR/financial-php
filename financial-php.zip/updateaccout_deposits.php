<?php
include 'partials/header.php';
require __DIR__ . '/users/users.php';

if (!isset($_GET['id'])) {
    include "partials/not_found.php";
    exit;
}
$userId = $_GET['id'];

$user = getUserById($userId);

if (!$user) {
    include "partials/not_found.php";
    exit;
}

$errors = [
    'ammount' => "",
    
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // $user_data['name']=$_POST['name'];
    // $user_data['email']=$_POST['email'];
    // $user_data['phone']=$_POST['phone'];
    // $user_data['id']=$_POST['id'];
    // $user_data['balance']=$_POST['balance'];
    // $user_data['id']=$_POST['id'];
    // $user_data['id']=$_POST['id'];

    $account['ammount']=$_POST['ammount'];
    $account['depositDate']=$_POST['depositDate'];
    $account['withdrawals_ammount']="";
    $account['withdrawals_date']="";
    $user_data[]=$account;

    // $user_data['ammount']=$_POST['ammount'];
    // $user_data['depositDate']=$_POST['depositDate'];
    // $user_data['balance']=$_POST['balance'];

    // echo "<pre>";
    // print_r($user_dd);
    // exit();

    $user = array_merge($user, $_POST);

    $isValid = validateUserDeposit($user, $errors);
    if ($isValid) {
        // $user = updateUser($user_data, $userId);
        $user = depositUser($user_data, $userId);
       
        header("Location: index.php");
    }
    
   
    
}

?>

<?php include '_form_deposits.php' ?>
